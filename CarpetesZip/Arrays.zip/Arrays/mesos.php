<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php

    $mesos = array (

        "Gener" => 31,
        "Febrer" => 28,
        "Març" => 31,
        "Abril" => 30,
        "Maig" => 31,
        "Juny" => 30,
        "Juliol" => 31,
        "Agost" => 31,
        "Setembre" => 30,
        "Octubre" => 31,
        "Novembre" => 31,
        "Desembre" => 31

    );

    echo $mesos["Setembre"];
           
    ?>

</body>
</html>